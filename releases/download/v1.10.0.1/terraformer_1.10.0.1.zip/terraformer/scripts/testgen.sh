../bin/terraformer -o ../resources/$1 ../data
