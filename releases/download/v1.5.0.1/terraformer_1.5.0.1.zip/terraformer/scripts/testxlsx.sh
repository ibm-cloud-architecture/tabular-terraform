../bin/terraformer -g 1 -o ../resources/gen1$2 -p $1gen1 ../data/xlsx
../bin/terraformer -g 2 -o ../resources/gen2$2 -p $1gen2 ../data/xlsx
