../bin/terraformer -o ../resources/$1 -t xlsx ../data
