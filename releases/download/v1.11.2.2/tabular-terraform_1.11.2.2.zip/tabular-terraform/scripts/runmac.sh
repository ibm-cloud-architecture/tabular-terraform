../bin/transform -o ../resources/$2 -t xlsx ../examples/$1
