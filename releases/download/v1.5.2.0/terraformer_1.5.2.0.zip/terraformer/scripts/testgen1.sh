../bin/terraformer -g 1 -o ../resources/gen1$2 -p $1gen1 ../data/xlsx
