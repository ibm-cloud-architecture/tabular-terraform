../bin/transform -o ../resources/$1 -t xlsx ../data
