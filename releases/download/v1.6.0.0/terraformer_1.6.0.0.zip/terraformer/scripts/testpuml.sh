../bin/terraformer -d -g 2 -o ../resources/gen2$2 -p $1gen2 ../data/xlsx
